import {getRepository} from "typeorm";
import {NextFunction, Request, Response} from "express";
import {Payment} from "../entity/Payment";
import {validate} from "class-validator";
import {Err,errCode,errMsg} from '../helper/Err'


export class PaymentController {
    public static get repo(){
        return getRepository(Payment)
    }

    static async create(request: Request, response: Response, next: NextFunction) {
        console.log(request.body)
        let {payNo,totalPrice,email}=request.body
        let payment = new Payment()
       payment.totalPrice=totalPrice
       payment.paymentNo=payNo
       payment.email=email
        try{
            console.log(payment)
            const errors =await validate(payment)
            console.log(errors)
            if (errors.length>0)
            {
                let err= new Err(errCode.E400,errMsg.Missing,null)
                return response.status(400).send(err)
            }
            console.log(payment)
            await PaymentController.repo.save(payment)
        }catch(e){
            console.log('error,write to db',e)
            return response.status(401).send(new Err(errCode.E400,errMsg.Fail,e))
        }
        return response.status(200).send(new Err(errCode.E200,errMsg.OK,payment))
       
    }}

   