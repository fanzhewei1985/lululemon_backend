import { ManyToOne, PrimaryGeneratedColumn, Column, Entity} from "typeorm";
import { Order } from "./Order";

@Entity()
export class OrderStatus {

@PrimaryGeneratedColumn()
id:number;

@Column()
name:string;

@ManyToOne(()=>Order,order=>order.orderStatus)
order:Order
}


