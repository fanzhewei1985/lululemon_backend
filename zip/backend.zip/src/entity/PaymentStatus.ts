import { ManyToOne, PrimaryGeneratedColumn, Column, Entity} from "typeorm";
import {Payment} from './Payment'

@Entity()
export class PaymentStatus {

@PrimaryGeneratedColumn()
id:number;

@Column()
name:string;

@ManyToOne(()=>Payment,payment=>payment.paymentStatus)
payment:Payment
}


