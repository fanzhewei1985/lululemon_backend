import { ManyToOne, PrimaryGeneratedColumn, Column, Entity} from "typeorm";
import {Payment} from './Payment'

@Entity()
export class PaymentType {

@PrimaryGeneratedColumn()
id:number;

@Column()
name:string;

@ManyToOne(()=>Payment,payment=>payment.paymentType)
payment:Payment
}



